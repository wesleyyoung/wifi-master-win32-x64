(() => {
    'use strict';

    const
        { exec } = require('child_process'),
        fs = require('fs'),
        express = require('express'),
        app = express(),
        bodyParser = require('body-parser'),
        server = require('http').Server(app),
        io = require('socket.io')(server),
        parseString = require('xml2js').parseString,
        pigod = require('pigod');

    app.use(bodyParser.urlencoded({ extended: true }));
    app.use(bodyParser.json());

    app.use('/node_modules', express.static(__dirname + '/node_modules'));

    app.set('PORT', 5080);

    var profile_cache_being_used = false;

    pigod.mkdir(__dirname + '\\wifi_profiles', (err) => {
        if (err) throw err;
    });

    pigod.mkdir(__dirname + '\\new_wifi_profiles', (err) => {
        if (err) throw err;
    });

    function clearProfileCache($done){
        if (!profile_cache_being_used){
            var 
                count = 0,
                profiles = [];

            function deleteFile($path){
                fs.unlink($path, (err) => {
                    if (err) throw err;
                    count++;
                    if (profiles[count]) deleteFile(profiles[count])
                    else $done();
                });
            }

            fs.readdir(__dirname + '\\wifi_profiles', (err, cur_profiles) => {
                cur_profiles.forEach((file, index) => {
                    profiles.push(__dirname + '\\wifi_profiles\\' + file);
                });
                fs.readdir(__dirname + '\\new_wifi_profiles', (err, new_profiles) => {
                    new_profiles.forEach((file, index) => {
                        profiles.push(__dirname + '\\new_wifi_profiles\\' + file);
                    });
                    if (profiles[count]) deleteFile(profiles[count])
                    else $done();
                });
            });
        } else {
            $done();
        }
        
    }

    function deleteProfile($ssid, $done){
        exec(`netsh wlan delete profile name="${$ssid}"`, (err, stdout, stderr) => {
            if (err) throw err;
            $done();
        });
    }

    function exportWiFiProfiles($done){
        clearProfileCache(() => {
            exec(`netsh wlan export profile folder="${__dirname + '\\wifi_profiles'}" key=clear`, (err, stdout, stderr) => {
                if (err) throw err;
                fs.readdir(__dirname + '\\wifi_profiles', (err, profiles) => {
                    if (err) throw err;
                    var
                        index = 0,
                        output = [];
                    function parseProfile($path){
                        fs.readFile(__dirname + '\\wifi_profiles\\' + $path, (err, xml) => {
                            if (err) throw err;
                            parseString(xml, function (err, json) {
                                if (err) throw err;
                                var profile = json.WLANProfile;
                                output.push({
                                    ssid: profile.name[0],
                                    key: profile.MSM[0].security[0].sharedKey ? profile.MSM[0].security[0].sharedKey[0].keyMaterial[0] : '',
                                    authentication: profile.MSM[0].security[0].authEncryption[0].authentication[0],
                                    encryption: profile.MSM[0].security[0].authEncryption[0].encryption[0],
                                    connectionMode: profile.connectionMode[0],
                                    connectionType: profile.connectionType[0]
                                })
                                index++;
                                if (index < profiles.length) parseProfile(profiles[index]);
                                else $done(output);
                            });
                        });
                    }
                    parseProfile(profiles[index]);
                });
            });
        });
    }

    io.on('connection', function (socket) {
        console.log('Connection Established!');
        socket.on('get-wifi-info', () => {
            exportWiFiProfiles((info) => {
                socket.emit('get-wifi-infoRETURN', info);
            });
        });
        socket.on('get-wifi-xml-profiles', () => {
            clearProfileCache(() => {
                exec(`netsh wlan export profile folder="${__dirname + '\\wifi_profiles'}" key=clear`, (err, stdout, stderr) => {
                    if (err) throw err;
                    fs.readdir(__dirname + '\\wifi_profiles', (err, profiles) => {
                        if (err) throw err;
                        var index = 0;
                        function parseProfile($path){
                            fs.readFile(__dirname + '\\wifi_profiles\\' + $path, (err, xml) => {
                                if (err) throw err;
                                socket.emit('get-wifi-xml-profilesUPDATE', xml.toString('utf8'));
                                index++;
                                if (index < profiles.length) parseProfile(profiles[index]);
                                else socket.emit('get-wifi-xml-profilesRETURN', {});
                            });
                        }
                        parseProfile(profiles[index]);
                    });
                }); 
            });
        });
        socket.on('delete-wifi-profile', (ssid) => {
            deleteProfile(ssid, () => {
                socket.emit('delete-wifi-profileRETURN', {});
            });
        });
        socket.on('new-xml-profile', (profile) => {
            parseString(profile.toString('utf8'), function (err, json) {
                if (err) throw err;
                var new_file_name = __dirname + '\\new_wifi_profiles\\Wi-Fi-' + json.WLANProfile.name[0] + '.xml';
                fs.writeFile(new_file_name, profile.toString('utf8'), (err) => {
                    if (err) throw err;
                });
            });
        });
        socket.on('apply-new-profiles', () => {
            var conflicts = [];
            fs.readdir(__dirname + '\\new_wifi_profiles', (err, new_profiles) => {
                if (err) throw err;
                fs.readdir(__dirname + '\\wifi_profiles', (err, current_profiles) => {
                    if (err) throw err;
                    var current_profiles_str = current_profiles.join(' ');
                    var file_name_count = 0;

                    function applyNewProfiles(prof){
                        var patt = new RegExp(prof, 'gi');
                        file_name_count++;
                        if (patt.test(current_profiles_str)) {
                            fs.readFile(__dirname + '\\new_wifi_profiles\\' + prof, (err, new_xml) => {
                                if (err) throw err;
                                fs.readFile(__dirname + '\\wifi_profiles\\' + prof, (err, old_xml) => {
                                    if (err) throw err;
                                    parseString(new_xml, function (err, new_json) {
                                        if (err) throw err;
                                        parseString(old_xml, function (err, old_json) {
                                            if (err) throw err;
                                            if (new_json.WLANProfile.MSM[0].security[0].sharedKey && old_json.WLANProfile.MSM[0].security[0].sharedKey){
                                                if (new_json.WLANProfile.MSM[0].security[0].sharedKey[0].keyMaterial[0] !== old_json.WLANProfile.MSM[0].security[0].sharedKey[0].keyMaterial[0]){
                                                    conflicts.push({
                                                        new_file_path: __dirname + '\\new_wifi_profiles\\' + prof,
                                                        old_file_path: __dirname + '\\wifi_profiles\\' + prof,
                                                        ssid: new_json.WLANProfile.name[0],
                                                        remoteKey: new_json.WLANProfile.MSM[0].security[0].sharedKey[0].keyMaterial[0],
                                                        localKey: old_json.WLANProfile.MSM[0].security[0].sharedKey[0].keyMaterial[0]
                                                    });
                                                    if (new_profiles[file_name_count]) applyNewProfiles(new_profiles[file_name_count]);
                                                    else finishApplication();
                                                } else {
                                                    if (new_profiles[file_name_count]) applyNewProfiles(new_profiles[file_name_count]);
                                                    else finishApplication();
                                                }
                                            } else {
                                                if (new_profiles[file_name_count]) applyNewProfiles(new_profiles[file_name_count]);
                                                else finishApplication();
                                            }
                                        });
                                    });
                                });
                            });
                        } else {
                            if (new_profiles[file_name_count]) applyNewProfiles(new_profiles[file_name_count]);
                            else finishApplication();
                        }
                    }

                    if (new_profiles[file_name_count]) applyNewProfiles(new_profiles[file_name_count])

                    var index = 0;

                    function finishApplication(){
                        if (conflicts.length == 0) {
                            loadProfilesIntoWindows()
                        } else {
                            handleConflict(conflicts[0])
                        }
                    }

                    function handleConflict(conflict){
                        socket.emit('apply-new-profilesPAUSE', conflict);
                        index++;
                        socket.on('apply-new-profilesRESUME', (resolution) => {
                            if (resolution.toString('utf8') == conflict.localKey) {
                                for(var i = 0; i < new_profiles.length; i++){
                                    if (new_profiles[i] == 'Wi-Fi-' + conflict.ssid + '.xml'){
                                        delete new_profiles[i];
                                        break;
                                    }
                                }
                                if (conflicts[index]) handleConflict(conflicts[index]);
                                else loadProfilesIntoWindows();
                            } else if (resolution.toString('utf8') == conflict.remoteKey){
                                deleteProfile(conflict.ssid, () => {
                                    if (conflicts[index]) handleConflict(conflicts[index]);
                                    else loadProfilesIntoWindows();
                                });
                            }
                            
                        });
                    }

                    var profile_apply_init = false;

                    function loadProfilesIntoWindows(){
                        if (!profile_apply_init){
                            profile_apply_init = true;
                        var new_profile_count = 0;
                        profile_cache_being_used = true;
                        for (var i = 0; i < new_profiles.length; i++){
                            var patt = new RegExp(new_profiles[i], 'gi');
                            if (new_profiles.join(' ').match(patt).length > 1) delete new_profiles[i];
                        }
                        function applyProfile($profile){
                            new_profile_count++;
                            if ($profile !== undefined){
                                exec(`netsh wlan add profile filename="${__dirname + '\\new_wifi_profiles\\' + $profile}"`, (err, stdout, stderr) => {
                                    if (err) throw err;
                                    if (new_profile_count < new_profiles.length) applyProfile(new_profiles[new_profile_count]);
                                    else finishProgStream();
                                });
                            } else {
                                if (new_profile_count < new_profiles.length) applyProfile(new_profiles[new_profile_count]);
                                else finishProgStream();
                            }   
                        }
                        if (new_profile_count < new_profiles.length) {
                            applyProfile(new_profiles[new_profile_count]);
                        }
                        else finishProgStream();
                        }
                    }

                    function finishProgStream(){
                        profile_cache_being_used = false;
                        socket.emit('apply-new-profilesRETURN', {});
                        socket.removeAllListeners('apply-new-profilesRESUME');
                    }

                });
            });
        });

    });

    exports.init = ($ENGINE_DONE_INIT) => {   

        server.listen(app.get('PORT'), () => {
            console.log(`App listening on port ${app.get('PORT')}...`);
            $ENGINE_DONE_INIT();
        });

    };
})();